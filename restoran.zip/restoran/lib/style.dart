import 'package:flutter/material.dart';

const bgutama =  Color(0xFFF2F1EB);
const iconfoodColor = Color.fromARGB(255, 82, 104, 86);
const bglistmenu = Color.fromARGB(255, 255, 254, 251);
const bgnamemenu = Color(0xFF88AB8E);