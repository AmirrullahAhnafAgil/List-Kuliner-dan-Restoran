const Map<String, String> profil = {
  'name': 'Nusantara Rasa',
  'email': 'muhammadashief17@gmail.com',
  'phone': '+6289503978440',
  'image': 'home.jpg',
  'description': 'Selamat datang di Nusantara Rasa, restoran yang menyajikan kelezatan masakan Jawa dengan sentuhan tradisional dan modern. Terletak di jantung kota, Nusantara Rasa adalah tempat di mana cita rasa autentik berpadu dengan suasana yang hangat dan ramah.',
  'address': 'Kota Semarang, Semarang, Jawa Tengah, Indonesia',
  'openingHours': '07.00 AM - 12.00 PM',
};